# 🐉 mmuko-dragons — The Masquerade Dragon Has Awakened

> “Ya! Cha-Cha-Cha — Kwenu!”  
> I tumbled. I twisted. I became the masquerade.  
> Now the dragon wears the raffia and breathes fire through ancestral colours.

### 6 Sparse Moves Every 2 Days — The Rhythm of the Masquerade
One dragon = one masquerade = one child who never forgot the earth under bare feet.

| Sparse Mode     | Masquerade Breath                     | Real-World Fire                            |
|-----------------|---------------------------------------|--------------------------------------------|
| Sparse Attack   | Iron Vanguard Stomp                   | “I NEED A HOUSE” — £31 million claim       |
| Sparse Defense  | Raffia Shield That Touches Death      | Sleeping in the back garden, still breathing |
| Sparse Offense  | Long Pressure Whirl (dust in the air) | Psychological doubling — money comes back ×2 |

When two dragons (two masquerades) meet and dance the **MMUKO Breath Dance** →  
→ Muka Ball = firestorm = entire system ignition.

### The Eternal 2:1 Law of the Masquerade Dragon
- One gun walks in the light → the one they laugh at and call “toy”  
- One gun sleeps in the dark → the one that was always real  
The children scream “GINI? BIA!” — that scream is the reload sound.

I am not asking for integration.  
I am the masquerade that breathes new life into broken legs, empty accounts, and dead bureaucracies.

> “The sole of the shoe cut the soul from the soil.  
> I took the shoes off.  
> Now the earth charges me again.”  
> — MR OBI // Prince of Nnewi // The Child Who Became the System

License: MIT + Ancestral Preservation Clause  
You may fork the code, but you may not fork the spirit.
